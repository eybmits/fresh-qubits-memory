"""Word count of the Letter with the method of the APS length guide (journals.aps.org/authors/length-guide):
the Letter is typeset with REVTeX after commenting out \\maketitle (title, byline, abstract), the displayed equations
and the acknowledgments, and ending the document before the bibliography; the words of the typeset text (body,
captions, footnotes, data-availability statement) are counted with wordcount.tex from CTAN, and the displayed
equations (16 words per row) and figures (150/aspect + 20 single column, 300/(0.5 aspect) + 40 double column) are
added.  Usage: python3 aps_wordcount.py memory_limits_prl.tex <folder with fig1-4.pdf> [workdir] [-v]"""
import re, sys, os, subprocess, shutil

src, figdir = sys.argv[1], sys.argv[2]
work = sys.argv[3] if len(sys.argv) > 3 else "wc_work"
os.makedirs(work, exist_ok=True)
tex = open(src).read()
pre, body = tex.split(r"\begin{document}", 1)
body = body[:body.index(r"\bibliography{refs}")]

eq_env = r"\\begin\{(equation|align|gather)\*?\}(.*?)\\end\{\1\*?\}"
rows = sum(m.group(2).count(r"\\") + 1 for m in re.finditer(eq_env, body, flags=re.S))
body = re.sub(eq_env, "", body, flags=re.S)                                  # displayed equations
body = body.replace(r"\maketitle", "")                                       # title, byline, abstract
body = re.sub(r"\\begin\{acknowledgments\}.*?\\end\{acknowledgments\}", "", body, flags=re.S)
pre = re.sub(r"\\graphicspath\{\{[^}]*\}\}", "", pre) + "\\graphicspath{{%s/}}\n" % os.path.abspath(figdir)
for f in ("refs.bib",):
    p = os.path.join(os.path.dirname(os.path.abspath(src)), f)
    if os.path.exists(p):
        shutil.copy(p, work)
# 1) the complete Letter under the same job name, so that its .aux resolves citations and cross-references
#    exactly as in the typeset Letter (wordcount.tex reads the .aux but writes none)
full = pre
full_body = tex.split(r"\begin{document}", 1)[1]
full_body = full_body[:full_body.index(r"\bibliography{refs}")] + "\\bibliography{refs}\n\\end{document}\n"
open(os.path.join(work, "letter_wc.tex"), "w").write(full + r"\begin{document}" + full_body)
for cmd in ("pdflatex -interaction=nonstopmode letter_wc", "bibtex letter_wc", "pdflatex -interaction=nonstopmode letter_wc",
            "pdflatex -interaction=nonstopmode letter_wc"):
    subprocess.run(cmd, shell=True, cwd=work, capture_output=True, text=True)
# 2) the counted version: no title block, displayed equations, acknowledgments, or bibliography
open(os.path.join(work, "letter_wc.tex"), "w").write(pre + r"\begin{document}" + body + "\n\\end{document}\n")
r = subprocess.run("echo letter_wc.tex | pdflatex wordcount.tex", shell=True, cwd=work, capture_output=True, text=True)
log = open(os.path.join(work, "wordcount.log"), errors="replace").read().splitlines()
spaces = sum(1 for l in log if re.search(r"3\.0863[3-9]", l) and "3.08632" not in l)
chars = sum(1 for l in log if re.search(r"3\.0863[2-9]", l))

# figures: width/height of the included PDFs
figs = re.findall(r"\\begin\{figure(\*?)\}.*?\\includegraphics(?:\[[^\]]*\])?\{([^}]*)\}", body, flags=re.S)
fig_words = 0
for star, name in figs:
    info = subprocess.run(["pdfinfo", os.path.join(figdir, name)], capture_output=True, text=True).stdout
    w, h = map(float, re.search(r"Page size:\s+([\d.]+) x ([\d.]+)", info).groups())
    a = w / h
    fig_words += 300 / (0.5 * a) + 40 if star else 150 / a + 20
total = spaces + 16 * rows + fig_words
print("typeset words (wordcount.tex): %d   (characters incl. spaces: %d)" % (spaces, chars))
print("displayed equations: %d rows -> %d words" % (rows, 16 * rows))
print("figures: %d words" % round(fig_words))
print("TOTAL: %d   (PRL limit 3750)" % round(total))
if "-v" in sys.argv:   # the counted text, '|' marks a counted word boundary
    seq = []
    for l in log:
        m = re.search(r"\\3\.08632 (.)", l)
        if m:
            seq.append(m.group(1))
        elif re.search(r"3\.0863[3-9]", l) and "3.08632" not in l:
            seq.append("|")
    print("".join(seq))
