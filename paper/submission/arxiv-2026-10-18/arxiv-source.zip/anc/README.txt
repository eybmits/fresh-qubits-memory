Reproducibility material for The Fundamental Memory Ceiling of Noisy Quantum Reservoirs

Download and unpack the COMPLETE arXiv source archive, then run:
  python3 anc/reconstruct_source.py /path/to/new-reproduction-directory

The destination must not exist. The helper verifies SHA-256 hashes and
restores the original complete layout: manuscript, bibliography, final
figure PDFs, README, figures/, sim/, and checks/. No scientific source
or data bytes are changed. Follow README.txt in the restored directory.

The four TikZ .tex sources are in figure_sources/ outside anc/, because
arXiv recommends excluding TeX files from ancillary directories. They
are explicitly ignored during manuscript compilation in 00README.json.
Only memory_limits_prl.tex is a top-level compilation target; it uses
the final root-level figure PDFs and includes the Supplemental Material.

Reproduction dependencies: Python 3, numpy, scipy, mpmath, matplotlib;
pdfLaTeX/BibTeX and the figure font packages stated in the original README.
No code is run by arXiv to recreate the figures.
